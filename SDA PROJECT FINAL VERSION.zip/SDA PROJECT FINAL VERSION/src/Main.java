   public class Main {
        public static void main(String[] args) {
            // compositive  by Ahmed Asad Butt
            //Creating Directories
            Directorycompositive rootDirectory= new Directorycompositive("FURC");
            Directorycompositive subDirectory1 = new Directorycompositive("Software and IT");
            Directorycompositive subDirectory2 = new Directorycompositive("SE Departement");
            Directorycompositive subDirectory3 = new Directorycompositive("4A");
            Directorycompositive subDirectory4 = new Directorycompositive("4B");
            Directorycompositive subDirectory5 = new Directorycompositive("4C");
            Directorycompositive subDirectory6 = new Directorycompositive("HEXA");
            //Creating Files
            Filecomposite file1 = new Filecomposite("SDA.txt");
            Filecomposite file2 = new Filecomposite("DBMS.txt");
            //Adding Folders/Directories
            rootDirectory.addChild(subDirectory1);
            subDirectory1.addChild(subDirectory2);
            subDirectory2.addChild(subDirectory3);
            subDirectory2.addChild(subDirectory4);
            subDirectory2.addChild(subDirectory5);
            subDirectory3.addChild(file1);
            subDirectory5.addChild(file2);
            subDirectory5.addChild(subDirectory6);
            //  subDirectory5.removeChild(subDirectory6);
            //subDirectory5.removeChild(file2);
            // subDirectory3.removeChild(file1);
            //subDirectory5.removeChild(file2);
              
              
              
            //Iterator By M.Suffian (138)
            //iterator is used in composite
             System.out.println("------------------------------------Currently in Root Directory:FURC------------------------------------");
             rootDirectory.list();
            //rootDirectory.listbychoice(subDirectory2);
            
            
             System.out.println("");

           
            //COMMAND BY M.FARZAM BAIG (136)
            // Create commands
            Directorycompositive newfolder; 
            Directorycompositive newfile; 
            Command createFileCommand = new CreateFileCommand("NewFile.txt");
            Command createDirectoryCommand = new CreateDirectoryCommand("Sample Folder");
            Command copyFileCommand = new CopyFileCommand("SourceFile.txt", "DestinationFile.txt");
            Command moveFileCommand = new MoveFileCommand("SourceFile.txt", "DestinationFile.txt");
            // Execute commands 
            newfolder= createDirectoryCommand.execute();
            createDirectoryCommand.execute();
            newfile=copyFileCommand.execute();
            moveFileCommand.execute();
            subDirectory5.addChild(newfolder);
            //subDirectory5.addChild(newfile);
            
            System.out.print("\n------------After Command Pattern------------");
            rootDirectory.list();
            
            //DECORATOR BY M.YASIR KHAN(139)
            Composite decoratedFile = new EncryptionDecorator(file1);
            decoratedFile.list();
            Composite decoratedDirectory = new CompressionDecorator(subDirectory1);
            decoratedDirectory.list();

        }
    }
//
//            // Decorate files or directories
//          //  Composite decoratedFile = new EncryptionDecorator(file1);
//           // decoratedFile.list();
//            while (iterator.hasNext()) {
//            Composite decoratedFile1 = iterator.next();
//            decoratedFile1.list();
//        }