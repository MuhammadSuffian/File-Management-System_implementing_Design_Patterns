    abstract class Decorator extends Composite {
        protected Composite component;
        static String N1;

        public Decorator(Composite component) {
            super(component.name);
            this.component = component;
        }
        public Decorator(Composite component,String end) {
            super(component.name);
            this.component = component;
            enc(end);
        }
         public Decorator(String end,Composite component) {
            super(component.name);
            this.component = component;
            comp(end);
        }

        @Override
        public void addChild(Composite component) {
            this.component.addChild(component);
        }

        @Override
        public void removeChild(Composite component) {
            this.component.removeChild(component);
        }

        @Override
        public Composite getChild(int index) {
            return this.component.getChild(index);
        }
        public void enc(String end){
        String[] parts =name.split("\\.");
       String test_name = parts[0];
       test_name=test_name +"."+end;
       N1= test_name;
       this.name = test_name;
        }
        
         public void comp(String end){
        String[] parts =name.split("\\.");
       String test_name = parts[0];
       test_name=test_name +"."+end;
       N1= test_name;
       this.name = test_name;
        }

   
        public void list() {
            System.out.println("File:"+N1);
             
        }
    }