class Filecomposite extends Composite {
    public Filecomposite(String name) {
        super(name);
    }

    @Override
    public void addChild(Composite component) {
        // Cannot add child to a file becasue a file is always a leaf note as explained in presentation
    }

    @Override
    public void removeChild(Composite component) {
        // Same reason
    }

    @Override
    public Composite getChild(int index) {
        //Same reason
        return null;
    }


    public void list() {
        System.out.println("File: " + name);
    }
    
    
    
    
    
    
    
    
    
    
    
    public void listv2() {          //ignore For test Purpose
        System.out.println("File: ");
    }
}