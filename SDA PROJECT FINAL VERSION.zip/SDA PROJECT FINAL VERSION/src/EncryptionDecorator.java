   class EncryptionDecorator extends Decorator {
      
        public EncryptionDecorator(Composite component) {
            super(component,"Enc");
  
        }

        @Override
        public void list() {
            System.out.println("---------------------------------------------------Encrypted Using Decorator---------------------------------------------------");
            super.list();
        }
    }