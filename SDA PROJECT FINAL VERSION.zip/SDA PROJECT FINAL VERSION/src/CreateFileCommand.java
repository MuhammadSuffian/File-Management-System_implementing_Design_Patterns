class CreateFileCommand implements Command {
    private String fileName;
    Directorycompositive n1;

    public CreateFileCommand(String fileName) {
        this.fileName = fileName;
        n1= new Directorycompositive(fileName);
    }

    public Directorycompositive execute() {
        System.out.println("Creating file: " + fileName);
        return n1;
    }
}