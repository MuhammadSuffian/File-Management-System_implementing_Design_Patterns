
import java.util.ArrayList;
import java.util.List;

class Directorycompositive extends Composite {
    public List<Composite> components;

    public Directorycompositive(String name) {
        super(name);
        this.components = new ArrayList<>();
    }

    @Override
    public void addChild(Composite component) {
        components.add(component);
    }

    @Override
    public void removeChild(Composite component) {
        components.remove(component);
    }

    @Override
    public Composite getChild(int index) {
        return components.get(index);
    }

    public void list() {
    System.out.println("\n"+"Directory: " + name);
    Iterator iterator = new DirectoryIterator(this);
    
    while (iterator.hasNext()) {
        Composite component = iterator.next();
        component.list();
       // System.out.println("Iterator Working");
    }
}
    
     public void listbychoice(Directorycompositive A) {
    // System.out.println("\n"+"Directory: " + name);
     System.out.println("\n"+"Directory: " + A.name);
    Iterator iterator = new DirectoryIterator(A);
    while (iterator.hasNext()) {
        Composite component = iterator.next();
        component.list();
       // System.out.println("Iterator Working");
    }
        System.out.println("");
}
}