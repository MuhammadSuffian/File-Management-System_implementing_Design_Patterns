import java.util.ArrayList;
import java.util.List;

    class DirectoryIterator implements Iterator {
        private Directorycompositive directory;
        private int currentIndex;

         DirectoryIterator(Directorycompositive directory) {
            this.directory = directory;
            this.currentIndex = 0;
        }

    DirectoryIterator(String a) {
        throw new UnsupportedOperationException("Not supported Sorry");
    }

        @Override
        public boolean hasNext() {
            return currentIndex < directory.components.size();
        }

        @Override
        public Composite next() {
            if (hasNext()) {
                Composite component = directory.components.get(currentIndex);
                currentIndex++;
                return component;
            }
            return null;
        }
    }

 