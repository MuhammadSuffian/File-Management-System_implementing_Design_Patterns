 interface Iterator {
        boolean hasNext();
        Composite next();
    }