interface Command {
    Directorycompositive execute();
}