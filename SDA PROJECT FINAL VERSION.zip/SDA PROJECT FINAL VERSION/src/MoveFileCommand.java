class MoveFileCommand implements Command {
    private String sourceFileName;
    private String destinationFileName;
   Directorycompositive n1;
    public MoveFileCommand(String sourceFileName, String destinationFileName) {
        this.sourceFileName = sourceFileName;
        this.destinationFileName = destinationFileName;
    }

    @Override
    public Directorycompositive execute() {
        System.out.println("Moving file: " + sourceFileName + " to " + destinationFileName);
        return n1;
    }
}