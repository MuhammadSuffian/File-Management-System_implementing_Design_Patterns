class CreateDirectoryCommand implements Command {
    private String directoryName;
    Directorycompositive n1;
    public CreateDirectoryCommand(String directoryName) {
        this.directoryName = directoryName;
        n1=new Directorycompositive(directoryName);
    }

    @Override
    public Directorycompositive execute() {
        System.out.println("Creating directory: " + directoryName);
        return n1;
       
    }
}