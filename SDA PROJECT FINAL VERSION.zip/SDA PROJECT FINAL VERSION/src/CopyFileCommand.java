class CopyFileCommand implements Command {
    private String sourceFileName;
    private String destinationFileName;
    Directorycompositive n1;
    public CopyFileCommand(String sourceFileName, String destinationFileName) {
        this.sourceFileName = sourceFileName;
        this.destinationFileName = destinationFileName;
    }

    public Directorycompositive execute() {
        System.out.println("Copying file: " + sourceFileName + " to " + destinationFileName);
       return n1;
    }
}