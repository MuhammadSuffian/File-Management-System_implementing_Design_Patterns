    class CompressionDecorator extends Decorator {
        public CompressionDecorator(Composite component) {
            super("rar",component);
        }

        @Override
        public void list() {
         System.out.println("---------------------------------------------------Compress Using Decorator---------------------------------------------------");
             super.list();
        }
    }