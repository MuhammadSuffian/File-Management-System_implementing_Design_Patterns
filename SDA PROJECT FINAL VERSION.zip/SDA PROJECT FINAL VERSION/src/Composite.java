 abstract class Composite {
    protected String name;

    public Composite(String name) {
        this.name = name;
    }
    
    

    public abstract void addChild(Composite component);
    public abstract void removeChild(Composite component);
    public abstract Composite getChild(int index);
    public abstract void list();
}